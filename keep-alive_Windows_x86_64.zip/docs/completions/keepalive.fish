complete -c keepalive -f
complete -c keepalive -s d -l duration -r -d "Duration to keep system alive (e.g., \"2h30m\" or \"150\")"
complete -c keepalive -s c -l clock -r -d "Time to keep system alive until (e.g., \"22:00\" or \"10:00PM\")"
complete -c keepalive -s a -l active -f -d "Keep chat apps (Slack/Teams) active by simulating activity"
complete -c keepalive -s l -l log -f -d "Enable logging to debug.log file"
complete -c keepalive -s v -l version -f -d "Show version information"
complete -c keepalive -s h -l help -f -d "Show help message"
